```markdown
# compliance-analyzer Development Patterns

> Auto-generated skill from repository analysis

## Overview
This skill teaches you how to contribute to the `compliance-analyzer` JavaScript codebase. You'll learn the project's coding conventions, how to add new modules and features, manage documentation, and handle deployment workflows. The repository is modular, with a focus on extensibility and clear documentation, and uses JavaScript without a framework.

## Coding Conventions

- **File Naming:**  
  Use `camelCase` for JavaScript files.  
  *Example:*  
  ```
  modules/vaultEncryption.js
  ```

- **Import Style:**  
  Use **relative imports** within modules.  
  *Example:*  
  ```js
  import helper from './helper.js';
  ```

- **Export Style:**  
  Use **default exports** for modules.  
  *Example:*  
  ```js
  // modules/reportGenerator.js
  export default function generateReport(data) {
    // ...
  }
  ```

- **Commit Messages:**  
  Freeform, typically around 54 characters. No enforced prefix.

## Workflows

### Add New Module Feature
**Trigger:** When you want to introduce a new feature or capability as a module.  
**Command:** `/add-module`

1. **Create a new module file** in `modules/` (e.g., `modules/vaultEncryption.js`).
2. **Update `index.html`** to include the new module script and integrate with the UI (add a tab, button, or handler as needed).
3. **Optionally update or create related test files** (e.g., `tests/tests.html`).
4. **Optionally update documentation** or the landing page (`landing.html`).

*Example:*
```js
// modules/vaultEncryption.js
export default function encrypt(data) {
  // encryption logic
}
```
```html
<!-- index.html -->
<script src="modules/vaultEncryption.js"></script>
<button onclick="useVaultEncryption()">Encrypt</button>
```

---

### Add or Update GitHub Pages Workflow
**Trigger:** When you want to set up or fix automated deployment to GitHub Pages.  
**Command:** `/update-pages-workflow`

1. **Create or modify** `.github/workflows/pages.yml` with the correct branch and trigger settings.
2. **Commit and push** the workflow file.

*Example:*
```yaml
# .github/workflows/pages.yml
name: Deploy to GitHub Pages
on:
  push:
    branches:
      - main
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      # deployment steps here
```

---

### Add Feature with Documentation
**Trigger:** When you want to introduce a new tool or major feature with supporting docs.  
**Command:** `/add-feature-docs`

1. **Create implementation file(s)** (e.g., `modules/newAnalyzer.js`).
2. **Add or update `README.md`** with usage and description.
3. **Add or update `requirements.txt` or `package.json`** if dependencies are needed.

*Example:*
```js
// modules/newAnalyzer.js
export default function analyze(input) {
  // analysis logic
}
```
```markdown
# README.md
## New Analyzer
Usage: ...
```

---

### Add or Update Project Documentation
**Trigger:** When you want to improve or add documentation for the project.  
**Command:** `/update-docs`

1. **Create or update `README.md`**.
2. **Optionally create or update** `SETUP.md`, `INTEGRATIONS.md`, or `LICENSE`.

*Example:*
```markdown
# SETUP.md
## Installation
Instructions here...
```

## Testing Patterns

- **Testing Framework:** Unknown (not specified).
- **Test File Pattern:** Files matching `*.test.*` (e.g., `module.test.js`).
- **Test Location:** Typically in a `tests/` directory or alongside modules.
- **How to Write Tests:**  
  Use the same coding conventions as modules.  
  *Example:*  
  ```js
  // modules/vaultEncryption.test.js
  import encrypt from './vaultEncryption.js';

  test('encrypts data', () => {
    // test logic
  });
  ```

## Commands

| Command                | Purpose                                                      |
|------------------------|--------------------------------------------------------------|
| /add-module            | Add a new functional module to the application               |
| /update-pages-workflow | Add or update the GitHub Pages deployment workflow           |
| /add-feature-docs      | Add a significant feature or tool with supporting docs       |
| /update-docs           | Add or update project-level documentation files              |
```