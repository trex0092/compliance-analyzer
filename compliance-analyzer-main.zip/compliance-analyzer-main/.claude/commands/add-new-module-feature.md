---
name: add-new-module-feature
description: Workflow command scaffold for add-new-module-feature in compliance-analyzer.
allowed_tools: ["Bash", "Read", "Write", "Grep", "Glob"]
---

# /add-new-module-feature

Use this workflow when working on **add-new-module-feature** in `compliance-analyzer`.

## Goal

Adds a new functional module to the application, such as encryption, integrations, or UI enhancements.

## Common Files

- `modules/*.js`
- `index.html`
- `tests/tests.html`
- `landing.html`

## Suggested Sequence

1. Understand the current state and failure mode before editing.
2. Make the smallest coherent change that satisfies the workflow goal.
3. Run the most relevant verification for touched files.
4. Summarize what changed and what still needs review.

## Typical Commit Signals

- Create new module file in modules/ (e.g., modules/vault-encryption.js, modules/report-generator.js)
- Update index.html to include the new module script and integrate with the UI (e.g., add tab, button, or handler)
- Optionally update or create related test files (e.g., tests/tests.html)
- Optionally update documentation or landing page

## Notes

- Treat this as a scaffold, not a hard-coded script.
- Update the command if the workflow evolves materially.