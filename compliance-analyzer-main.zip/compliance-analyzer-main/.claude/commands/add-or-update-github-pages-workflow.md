---
name: add-or-update-github-pages-workflow
description: Workflow command scaffold for add-or-update-github-pages-workflow in compliance-analyzer.
allowed_tools: ["Bash", "Read", "Write", "Grep", "Glob"]
---

# /add-or-update-github-pages-workflow

Use this workflow when working on **add-or-update-github-pages-workflow** in `compliance-analyzer`.

## Goal

Adds or updates the GitHub Pages deployment workflow to ensure the site is deployed from the correct branch.

## Common Files

- `.github/workflows/pages.yml`

## Suggested Sequence

1. Understand the current state and failure mode before editing.
2. Make the smallest coherent change that satisfies the workflow goal.
3. Run the most relevant verification for touched files.
4. Summarize what changed and what still needs review.

## Typical Commit Signals

- Create or modify .github/workflows/pages.yml with correct branch and trigger settings
- Commit and push the workflow file

## Notes

- Treat this as a scaffold, not a hard-coded script.
- Update the command if the workflow evolves materially.