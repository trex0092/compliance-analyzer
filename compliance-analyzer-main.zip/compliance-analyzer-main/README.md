# 🔍 Compliance Analyser v2.3

AI-powered compliance analysis platform for UAE gold and precious metals trading. Supports regulatory frameworks including UAE FDL No.10/2025, FATF, UAE FIU, OECD, EOCN, MOE, and LBMA RGG V9.

## Features

| Tab | Description |
|-----|-------------|
| **Analyse** | AI-powered compliance gap analysis with PDF export |
| **Shipments** | 40+ field shipment tracking with risk scoring |
| **Asana Tasks** | Task management synced with Asana |
| **Evidence Tracker** | Evidence collection with Asana sync |
| **Scheduled Analysis** | Recurring compliance analysis scheduling |
| **Drive Structure** | Google Drive file organization |
| **Gap Register** | Pre-defined compliance gaps with Asana writeback |
| **Compliance Ops** | Screening rules, transaction monitoring, KYC reviews, STR workspace |
| **Companies** | Multi-tenant workspace for 6 company profiles |
| **Employee Training** | 43-item curriculum catalog with completion tracking |
| **Screening** | Sanctions and PEP database screening |
| **Onboarding** | KYC/CDD wizard with risk scoring |
| **Incidents** | Incident register and whistleblower reporting |
| **Dashboard** | Overview and analytics |
| **Calendar** | Schedule management |
| **Vault** | Secure data storage |
| **Drive** | Google Drive document management |
| **Settings** | API keys, proxy URL, integration configuration |

## Integrations

| Service | Purpose | Required |
|---------|---------|----------|
| **Claude (Anthropic)** | Primary AI analysis engine | Yes |
| **OpenAI** | Fallback AI provider | No |
| **Google Gemini** | Tertiary AI fallback | No |
| **Asana** | Task management and compliance tracking | Yes |
| **Notion** | Database and evidence storage | No |
| **Slack** | Alerts and notifications | No |
| **ClickUp** | Alternative task management | No |
| **Google Drive** | Document storage and audit trails | No |
| **EmailJS** | Email alerts and reminders | No |

## Quick Start

```bash
git clone https://github.com/trex051192/compliance-analyzer.git
cd compliance-analyzer
npm install
npm start
```

See [SETUP.md](SETUP.md) for full deployment instructions including Cloudflare Worker proxy setup.

See [INTEGRATIONS.md](INTEGRATIONS.md) for detailed integration documentation.

## Architecture

```
Browser (index.html) ──► Cloudflare Worker (proxy) ──► APIs
                              │
                              ├── Anthropic (Claude)
                              ├── OpenAI
                              ├── Gemini
                              ├── Asana
                              ├── Notion
                              ├── Slack
                              └── ClickUp
```

All API keys stored server-side in Cloudflare Worker secrets. No credentials exposed to the browser.

## License

[MIT](LICENSE)

---

Built by [trex051192](https://github.com/trex051192)
