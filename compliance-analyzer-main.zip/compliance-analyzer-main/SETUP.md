# Setup Guide — Compliance Analyser v2.3

## Prerequisites

- [Cloudflare account](https://dash.cloudflare.com/) (free tier works)
- [Node.js](https://nodejs.org/) v18+
- [Wrangler CLI](https://developers.cloudflare.com/workers/wrangler/) (`npm install -g wrangler`)

## 1. Deploy the Cloudflare Worker (API Proxy)

The proxy keeps all API keys server-side. No credentials are exposed in the browser.

```bash
cd proxy/
wrangler login
wrangler deploy
```

After deployment, note your Worker URL:
```
https://fgl-proxy.<your-subdomain>.workers.dev
```

### Set Required Secrets

```bash
wrangler secret put ANTHROPIC_KEY
# Paste your Anthropic API key (sk-ant-...)

wrangler secret put ASANA_TOKEN
# Paste your Asana personal access token (1/xxxxxxxx...)
```

### Set Optional Secrets

```bash
wrangler secret put OPENAI_KEY        # OpenAI API key (sk-...)
wrangler secret put GEMINI_KEY        # Google Gemini key (AIza...)
wrangler secret put NOTION_TOKEN      # Notion integration token (ntn_...)
wrangler secret put CLICKUP_TOKEN     # ClickUp API token (pk_...)
```

## 2. Configure the App

1. Open the app in your browser
2. Go to **Settings** tab
3. Enter the **Proxy URL** (your Cloudflare Worker URL)
4. Configure integrations:
   - **Asana**: Project and workspace IDs are pre-configured
   - **Notion**: Enter your Notion database ID
   - **Slack**: Enter your Slack webhook URL
   - **ClickUp**: Enter your ClickUp list ID
   - **Google Drive**: Enter your OAuth client ID and folder ID
5. Toggle **Remember Keys** to persist settings in localStorage

## 3. Run Locally

```bash
npm install
npm start
# Opens at http://localhost:8080
```

## 4. Deploy to GitHub Pages

The app auto-deploys to GitHub Pages on every push to `main` via the workflow in `.github/workflows/pages.yml`.

To deploy manually:
1. Push changes to `main` branch
2. GitHub Actions will build and deploy automatically
3. Access at `https://<username>.github.io/<repo-name>/`

## 5. CORS Configuration

The proxy only accepts requests from whitelisted origins. Update `proxy/worker.js` if your domain changes:

```javascript
const ALLOWED_ORIGINS = [
  'https://trex051192.github.io',
  'https://compliancetool.com',
  'https://www.compliancetool.com',
];
```

## Troubleshooting

| Issue | Solution |
|-------|----------|
| API returns 403 | Check CORS origins in worker.js match your domain |
| Anthropic/OpenAI errors | Verify secrets are set: `wrangler secret list` |
| Asana sync fails | Check ASANA_TOKEN is valid and has project access |
| Google Drive not connecting | Ensure OAuth client ID is configured and authorized |
| Pages not deploying | Check GitHub Actions tab for workflow errors |
