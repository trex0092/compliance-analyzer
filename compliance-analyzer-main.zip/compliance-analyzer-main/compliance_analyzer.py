import streamlit as st
import openai
import json
from typing import Optional

# Compliance frameworks and their key requirements
COMPLIANCE_FRAMEWORKS = {
    "GDPR": {
        "name": "General Data Protection Regulation",
        "key_areas": [
            "Data collection and consent",
            "Data subject rights (access, rectification, erasure)",
            "Data processing agreements",
            "Cross-border data transfers",
            "Data breach notification",
            "Privacy by design and default",
            "Data Protection Impact Assessment (DPIA)",
            "Lawful basis for processing",
        ],
    },
    "HIPAA": {
        "name": "Health Insurance Portability and Accountability Act",
        "key_areas": [
            "Protected Health Information (PHI) handling",
            "Administrative safeguards",
            "Physical safeguards",
            "Technical safeguards",
            "Business Associate Agreements",
            "Minimum necessary standard",
            "Patient rights and access",
            "Breach notification requirements",
        ],
    },
    "SOC2": {
        "name": "Service Organization Control 2",
        "key_areas": [
            "Security (common criteria)",
            "Availability",
            "Processing integrity",
            "Confidentiality",
            "Privacy",
            "Access controls",
            "Change management",
            "Risk assessment",
        ],
    },
    "PCI-DSS": {
        "name": "Payment Card Industry Data Security Standard",
        "key_areas": [
            "Network security controls",
            "Cardholder data protection",
            "Vulnerability management",
            "Access control measures",
            "Network monitoring and testing",
            "Information security policy",
            "Encryption of cardholder data",
            "Authentication mechanisms",
        ],
    },
    "ISO 27001": {
        "name": "Information Security Management System",
        "key_areas": [
            "Information security policies",
            "Organization of information security",
            "Asset management",
            "Access control",
            "Cryptography",
            "Physical and environmental security",
            "Operations security",
            "Incident management",
        ],
    },
}


def get_analysis_prompt(framework: str, document_text: str) -> str:
    framework_info = COMPLIANCE_FRAMEWORKS[framework]
    key_areas = "\n".join(f"- {area}" for area in framework_info["key_areas"])

    return f"""You are an expert compliance analyst specializing in {framework} ({framework_info['name']}).

Analyze the following document/policy text for compliance with {framework} requirements.

Key areas to evaluate:
{key_areas}

For each area, provide:
1. **Status**: Compliant, Partially Compliant, Non-Compliant, or Not Addressed
2. **Findings**: Specific observations from the document
3. **Recommendations**: Actionable steps to improve compliance

Document to analyze:
---
{document_text}
---

Provide your analysis in the following JSON format:
{{
    "overall_score": <number 0-100>,
    "overall_status": "<Compliant|Partially Compliant|Non-Compliant>",
    "summary": "<brief executive summary>",
    "findings": [
        {{
            "area": "<key area name>",
            "status": "<Compliant|Partially Compliant|Non-Compliant|Not Addressed>",
            "findings": "<specific observations>",
            "recommendations": "<actionable recommendations>"
        }}
    ],
    "critical_gaps": ["<list of most critical gaps that need immediate attention>"],
    "next_steps": ["<prioritized list of recommended next steps>"]
}}

Return ONLY valid JSON, no additional text."""


def analyze_document(
    client: openai.OpenAI, model: str, framework: str, document_text: str
) -> Optional[dict]:
    prompt = get_analysis_prompt(framework, document_text)
    try:
        response = client.chat.completions.create(
            model=model,
            messages=[
                {
                    "role": "system",
                    "content": "You are a compliance analysis expert. Always respond with valid JSON.",
                },
                {"role": "user", "content": prompt},
            ],
            temperature=0.1,
            response_format={"type": "json_object"},
        )
        return json.loads(response.choices[0].message.content)
    except json.JSONDecodeError:
        st.error("Failed to parse analysis response. Please try again.")
        return None
    except openai.APIError as e:
        st.error(f"API error: {e}")
        return None


def render_status_badge(status: str) -> str:
    colors = {
        "Compliant": "green",
        "Partially Compliant": "orange",
        "Non-Compliant": "red",
        "Not Addressed": "gray",
    }
    color = colors.get(status, "gray")
    return f":{color}[**{status}**]"


def render_score_metric(score: int):
    if score >= 80:
        delta_color = "normal"
    elif score >= 50:
        delta_color = "off"
    else:
        delta_color = "inverse"

    threshold = 80
    delta = score - threshold
    st.metric(
        label="Overall Compliance Score",
        value=f"{score}/100",
        delta=f"{delta:+d} from threshold ({threshold})",
        delta_color=delta_color,
    )


def render_results(results: dict, framework: str):
    st.divider()
    st.header(f"Compliance Analysis: {framework}")

    col1, col2 = st.columns([1, 2])
    with col1:
        render_score_metric(results.get("overall_score", 0))
        overall_status = results.get("overall_status", "Unknown")
        st.markdown(f"**Overall Status:** {render_status_badge(overall_status)}")

    with col2:
        st.subheader("Executive Summary")
        st.write(results.get("summary", "No summary available."))

    st.subheader("Detailed Findings")
    findings = results.get("findings", [])
    for finding in findings:
        area = finding.get("area", "Unknown Area")
        status = finding.get("status", "Unknown")
        with st.expander(f"{area} — {status}"):
            st.markdown(f"**Status:** {render_status_badge(status)}")
            st.markdown(f"**Findings:** {finding.get('findings', 'N/A')}")
            st.markdown(
                f"**Recommendations:** {finding.get('recommendations', 'N/A')}"
            )

    critical_gaps = results.get("critical_gaps", [])
    if critical_gaps:
        st.subheader("Critical Gaps")
        for gap in critical_gaps:
            st.markdown(f"- :red[{gap}]")

    next_steps = results.get("next_steps", [])
    if next_steps:
        st.subheader("Recommended Next Steps")
        for i, step in enumerate(next_steps, 1):
            st.markdown(f"{i}. {step}")


def main():
    st.set_page_config(
        page_title="AI Compliance Analyzer",
        page_icon="🔍",
        layout="wide",
    )

    st.title("🔍 AI Compliance Analyzer")
    st.markdown(
        "Analyze your documents, policies, and code for regulatory compliance "
        "using AI. Select a compliance framework, paste your document, and get "
        "an instant compliance assessment with actionable recommendations."
    )

    with st.sidebar:
        st.header("Configuration")
        api_key = st.text_input("OpenAI API Key", type="password")
        model = st.selectbox(
            "Model",
            ["gpt-4o", "gpt-4o-mini", "gpt-4-turbo", "gpt-3.5-turbo"],
            index=0,
        )
        st.divider()
        st.header("About")
        st.markdown(
            "This tool uses LLMs to analyze documents against major compliance "
            "frameworks. It provides a compliance score, detailed findings per "
            "requirement area, and actionable recommendations."
        )
        st.markdown(
            "**Supported Frameworks:** GDPR, HIPAA, SOC2, PCI-DSS, ISO 27001"
        )
        st.warning(
            "This tool provides AI-assisted analysis only. Always consult "
            "qualified compliance professionals for official assessments.",
            icon="⚠️",
        )

    framework = st.selectbox(
        "Select Compliance Framework",
        list(COMPLIANCE_FRAMEWORKS.keys()),
        format_func=lambda x: f"{x} — {COMPLIANCE_FRAMEWORKS[x]['name']}",
    )

    st.info(
        f"**{framework}** key areas: "
        + ", ".join(COMPLIANCE_FRAMEWORKS[framework]["key_areas"]),
        icon="ℹ️",
    )

    input_method = st.radio(
        "Input Method", ["Paste Text", "Upload File"], horizontal=True
    )

    document_text = ""
    if input_method == "Paste Text":
        document_text = st.text_area(
            "Paste your document, policy, or code below:",
            height=300,
            placeholder="Paste your privacy policy, security documentation, "
            "infrastructure configuration, or any text to analyze...",
        )
    else:
        uploaded_file = st.file_uploader(
            "Upload a text file (.txt, .md, .py, .json, .yaml, .yml)",
            type=["txt", "md", "py", "json", "yaml", "yml"],
        )
        if uploaded_file is not None:
            document_text = uploaded_file.read().decode("utf-8")
            st.text_area("File contents:", document_text, height=300, disabled=True)

    if st.button("Analyze Compliance", type="primary", use_container_width=True):
        if not api_key:
            st.error("Please enter your OpenAI API key in the sidebar.")
            return
        if not document_text.strip():
            st.error("Please provide a document to analyze.")
            return

        client = openai.OpenAI(api_key=api_key)
        with st.spinner(f"Analyzing document against {framework} requirements..."):
            results = analyze_document(client, model, framework, document_text)

        if results:
            render_results(results, framework)

            st.download_button(
                label="Download Full Report (JSON)",
                data=json.dumps(results, indent=2),
                file_name=f"compliance_report_{framework.lower().replace(' ', '_')}.json",
                mime="application/json",
            )


if __name__ == "__main__":
    main()
