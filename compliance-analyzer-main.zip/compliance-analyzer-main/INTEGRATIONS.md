# Integrations Guide — Compliance Analyser v2.3

## AI Providers

### Claude (Anthropic) — Primary
- **Purpose**: Core AI engine for compliance analysis
- **Proxy Route**: `POST /anthropic`
- **API**: `https://api.anthropic.com/v1/messages`
- **Secret**: `ANTHROPIC_KEY`
- **Required**: Yes

### OpenAI — Fallback
- **Purpose**: Secondary AI provider
- **Proxy Route**: `POST /openai`
- **API**: `https://api.openai.com/v1/chat/completions`
- **Secret**: `OPENAI_KEY`
- **Required**: No (optional fallback)

### Google Gemini — Tertiary
- **Purpose**: Third-tier AI fallback
- **Proxy Route**: `POST /gemini`
- **API**: `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent`
- **Secret**: `GEMINI_KEY`
- **Required**: No (optional fallback)

---

## Project Management

### Asana
- **Purpose**: Task creation from compliance findings, sync state tracking
- **Proxy Route**: `GET|POST|PUT /asana/*`
- **API**: `https://app.asana.com/api/1.0/*`
- **Secret**: `ASANA_TOKEN`
- **Required**: Yes
- **Pre-configured**:
  - Project ID: `1213759768596515`
  - Workspace ID: `1213645083721316`
  - 6 compliance phase sections with IDs
  - 3 priority levels (High/Medium/Low)
- **Features**: Auto-sync every 3 minutes, retry queue, conflict management

### Notion
- **Purpose**: Database linking, evidence storage
- **Proxy Route**: `GET|POST /notion/*`
- **API**: `https://api.notion.com/v1/*`
- **Secret**: `NOTION_TOKEN`
- **Required**: No
- **Configuration**: Set `NOTION_DB_ID` in Settings

### ClickUp
- **Purpose**: Alternative task management
- **Proxy Route**: `GET|POST /clickup/*`
- **API**: `https://api.clickup.com/api/v2/*`
- **Secret**: `CLICKUP_TOKEN`
- **Required**: No
- **Configuration**: Set `CLICKUP_LIST_ID` in Settings

---

## Communication

### Slack
- **Purpose**: Alerts, notifications, compliance reporting
- **Proxy Route**: `POST /slack`
- **Authentication**: Webhook URL in request payload
- **Validation**: URL must start with `https://hooks.slack.com/`
- **Required**: No
- **Configuration**: Set webhook URL in Settings

### EmailJS
- **Purpose**: Email alerts and hourly reminders
- **Connection**: Direct (not proxied)
- **Required**: No
- **Error handling**: Categorizes auth, CORS, rate limit, and network errors

---

## Storage & Documents

### Google Drive
- **Purpose**: Document storage, audit trail management
- **Authentication**: OAuth 2.0 client ID
- **Connection**: Direct (not proxied)
- **Required**: No
- **Configuration**: Set `GDRIVE_CLIENT_ID` and `GDRIVE_FOLDER_ID` in Settings

---

## External Data

### Metals Pricing
- **Purpose**: Live gold/silver/platinum prices for shipment valuation
- **Sources** (triple fallback):
  1. `gold-api.com` — Primary
  2. `metals.live` — Secondary
  3. Reuters via `allorigins.win` CORS proxy — Tertiary
- **Refresh**: Every 30 seconds (pauses when tab is hidden)

---

## Security Architecture

```
Browser (index.html)
    │
    ├── API calls ──► Cloudflare Worker (proxy/worker.js)
    │                     │
    │                     ├── /anthropic ──► Anthropic API
    │                     ├── /openai    ──► OpenAI API
    │                     ├── /gemini    ──► Google Gemini API
    │                     ├── /asana/*   ──► Asana API
    │                     ├── /notion/*  ──► Notion API
    │                     ├── /slack     ──► Slack Webhook
    │                     └── /clickup/* ──► ClickUp API
    │
    ├── OAuth 2.0 ──► Google Drive (direct)
    ├── Direct    ──► EmailJS (direct)
    └── Direct    ──► Metals pricing APIs (direct)
```

All sensitive API keys are stored as Cloudflare Worker secrets — never exposed to the browser.
