# UAE DPMS Compliance Analyzer - Full Tool Report

**Report Date:** March 31, 2026
**Version:** 2.1.0
**Repository:** trex051192/compliance-analyzer
**Deployment:** GitHub Pages (Single-Page Application)

---

## 1. Executive Summary

The UAE DPMS Compliance Analyzer is a **zero-backend, single-page browser application** designed for UAE gold and precious metals dealers (Designated Non-Financial Businesses and Professions - DNFBPs) to manage their Anti-Money Laundering / Countering the Financing of Terrorism (AML/CFT) compliance obligations.

The tool runs entirely in the browser, deployed on GitHub Pages, with all data persisted in `localStorage` / `IndexedDB`. External API calls are routed securely through a Cloudflare Worker proxy to protect API keys.

---

## 2. Codebase Statistics

| Metric | Value |
|--------|-------|
| Total lines of code | ~19,700 |
| Main application file (`index.html`) | 11,256 lines |
| JavaScript modules | 15 files (8,465 lines) |
| Tabs / major sections | 35 |
| Storage keys | 47+ (`fgl_` prefix, company-scoped) |
| Synchronous functions | 347 |
| Asynchronous functions | 57 |
| External CDN libraries | 3 (jsPDF, EmailJS, Chart.js) |
| Integrations | 9 (2 required + 7 optional) |
| Multi-tenancy support | 6 company profiles with isolated data |

---

## 3. Application Tabs & Sections (35 Total)

### 3.1 Core Operations

| # | Tab | Description |
|---|-----|-------------|
| 1 | **Dashboard** | Key compliance indicators (12 metrics), upcoming regulatory deadlines widget, Board/MLRO report summary |
| 2 | **AI Analysis** | Claude-powered compliance gap analysis with dynamic prompt builder and multi-provider fallback |
| 3 | **Asana Sync** | Task management integration with 3-minute auto-sync, retry queue (max 40), conflict detection |
| 4 | **IAR Shipments** | International shipment tracking with 40+ fields and automated risk scoring |
| 5 | **Local Shipments** | Domestic shipment data management |
| 6 | **IAR Report** | Immediate Action Reports with UBO/manager tracking |
| 7 | **Evidence** | Evidence collection, tagging, and Asana synchronization |
| 8 | **Schedule** | Recurring compliance analysis scheduling |

### 3.2 Compliance Programme

| # | Tab | Description |
|---|-----|-------------|
| 9 | **Compliance Programme** | Three sub-tabs: Entity-Wide Risk Assessment (EWRA), Business-Wide Risk Assessment (BWRA), Compliance Manual |
| 10 | **Gap Register** | Pre-defined compliance gap tracking with status management |
| 11 | **Operations** | Screening rules, transaction monitoring thresholds, KYC settings |
| 12 | **Risk Assessment** | Risk assessment creation with professional color-coded PDF and Word export |
| 13 | **Onboarding** | KYC/CDD customer onboarding wizard with risk scoring |
| 14 | **Incidents** | Incident register and whistleblower reporting |

### 3.3 People & Training

| # | Tab | Description |
|---|-----|-------------|
| 15 | **Companies** | Multi-tenant workspace supporting 6 company profiles |
| 16 | **Training** | 77-topic employee training curriculum covering all AML/CFT areas |
| 17 | **Learning** | External learning resource links |
| 18 | **Employees** | Employee information and training records management |

### 3.4 Screening & Monitoring

| # | Tab | Description |
|---|-----|-------------|
| 19 | **Screening** | Sanctions and PEP database screening |
| 20 | **Threshold Monitor** | AED 55,000 DPMS cash transaction detection and structuring pattern alerts |
| 21 | **Regulatory Monitor** | Real-time regulatory framework tracking with health scoring |
| 22 | **Regulatory Changes** | Change tracking and impact analysis |

### 3.5 Reporting & Export

| # | Tab | Description |
|---|-----|-------------|
| 23 | **Reports** | 7+ report templates (Executive, Gap Analysis, Audit, Risk, Incident, EWRA/BWRA, CDD) |
| 24 | **goAML Export** | UAE FIU-compliant XML export for STR, SAR, CTR, FFR, and HRC reports |
| 25 | **Analytics** | Chart.js visual analytics, KPI snapshots, trend analysis |

### 3.6 Security & Storage

| # | Tab | Description |
|---|-----|-------------|
| 26 | **Vault** | AES-GCM 256-bit encrypted document storage with PBKDF2 key derivation |
| 27 | **Google Drive** | Document management integration |
| 28 | **Settings** | API keys, proxy URL, integration configuration |

### 3.7 Compliance Management

| # | Tab | Description |
|---|-----|-------------|
| 29 | **Management Approvals** | Customer and counterparty due diligence with 7-section assessment framework |
| 30 | **Supply Chain** | LBMA RGG v9 and OECD traceability, CAHRA risk tracking |
| 31 | **Workflows** | Automation rules, 5 compliance checklists, document version control |
| 32 | **Calendar** | 55-item UAE regulatory calendar across 9 categories |

### 3.8 Reference & Configuration

| # | Tab | Description |
|---|-----|-------------|
| 33 | **Integrations** | Integration health and status dashboard |
| 34 | **RACI Matrix** | Responsibility assignment matrix |
| 35 | **Definitions** | Custom term definitions and changelog |

---

## 4. JavaScript Modules (15 Files)

| Module | Lines | Purpose |
|--------|-------|---------|
| `workflow-engine.js` | 994 | Automation rules, alert escalation, 5 compliance checklists (New Customer Onboarding, Periodic Review, STR Filing, Incident Response, MOE Inspection Readiness), document version control |
| `report-generator.js` | 993 | PDF/DOCX report generation with 7+ templates, scheduling, history tracking |
| `auth-rbac.js` | 823 | Client-side authentication, role-based access control with 4 roles: Admin, Compliance Officer, Analyst, Viewer |
| `database.js` | 749 | IndexedDB backend for persistent storage with migration path from localStorage |
| `analytics-dashboard.js` | 656 | Chart.js-powered visual analytics, KPI snapshots (365-day retention), trend charts, Asana metrics |
| `integrations-enhanced.js` | 647 | Asana, Notion, Slack, Google Drive, ClickUp integration management with health monitoring |
| `management-approvals.js` | 543 | Customer and counterparty due diligence, 7-section assessment framework with Asana sync |
| `regulatory-monitor.js` | 536 | Real-time regulatory framework tracking, alerts, health scoring for UAE FDL, FATF, LBMA, and more |
| `vault-encryption.js` | 518 | AES-GCM 256-bit encryption at rest with PBKDF2 key derivation for sensitive documents |
| `goaml-export.js` | 438 | UAE FIU goAML-compliant XML export supporting STR, SAR, CTR, FFR, and HRC report types |
| `supply-chain.js` | 414 | LBMA Responsible Gold Guidance v9, OECD due diligence, CAHRA risk tracking, audit compliance |
| `tfs-refresh.js` | 418 | 15+ sanctions list management including UN, OFAC, EU, UK, UAE, INTERPOL, and PEP databases |
| `webhook-receiver.js` | 359 | Polling-based webhook event processor for Asana and Slack real-time events (30-second intervals) |
| `threshold-monitor.js` | 246 | AED 55,000 DPMS cash transaction detection, structuring pattern alerts, CTR workflow management |
| `mobile-responsive.js` | 131 | Hamburger menu, touch-friendly enhancements, 768px responsive breakpoint |

---

## 5. Integrations (9 Total)

### 5.1 Required Integrations

| Integration | Purpose | Details |
|-------------|---------|---------|
| **Anthropic Claude** | Primary AI engine | Powers compliance gap analysis, recommendations, and prompt building. Functions: `callAnthropic()`, `runAnalysis()`, `buildSystemPrompt()` |
| **Asana** | Task management | Project ID `1213759768596515`, Workspace `1213645083721316`. Auto-sync every 3 minutes, retry queue (max 40 items), conflict detection via fingerprinting. Syncs: risk assessments, EWRA/BWRA, compliance manual, incidents, onboarding, deadlines, screening, management approvals, workflow tasks |

### 5.2 Optional Integrations

| Integration | Purpose | Details |
|-------------|---------|---------|
| **OpenAI** | Fallback AI provider | Second in the AI fallback chain (Claude -> OpenAI -> Gemini) |
| **Google Gemini** | Tertiary AI fallback | Third in the AI fallback chain |
| **Notion** | Database storage | Evidence and document database integration |
| **ClickUp** | Task management | Alternative task management platform |
| **Slack** | Notifications | Webhook-based alerts and compliance notifications |
| **Google Drive** | Document storage | OAuth 2.0 authenticated document management and audit trail |
| **EmailJS** | Email alerts | Browser-based email notifications and hourly reminders |

### 5.3 Additional Services

| Service | Purpose | Details |
|---------|---------|---------|
| **Metals Pricing** | Live commodity rates | Triple-fallback: gold-api.com -> metals.live -> Reuters (CORS proxy). Refreshes every 30 seconds |

---

## 6. Regulatory Frameworks Covered

### 6.1 Primary Frameworks

- **UAE Federal Decree-Law No. 10/2025** - Anti-Money Laundering and Countering the Financing of Terrorism
- **UAE Cabinet Decision No. 10/2019** - Implementing Regulations
- **CBUAE AML/CFT Guidance** - Central Bank of the UAE guidelines
- **MOE (Ministry of Economy)** - DNFBP supervisory requirements

### 6.2 International Standards

- **FATF 40 Recommendations** - Financial Action Task Force standards
- **FATF Mutual Evaluation Reports** - Country assessment tracking
- **LBMA Responsible Gold Guidance v9** - London Bullion Market Association supply chain standards
- **OECD Due Diligence Guidance** - Conflict minerals and responsible sourcing

### 6.3 Sanctions Regimes (15+ Lists)

- UN Security Council Consolidated Sanctions List
- OFAC SDN (Specially Designated Nationals) List
- OFAC SSI (Sectoral Sanctions Identifications) List
- EU Consolidated Financial Sanctions List
- UK HM Treasury Sanctions List
- UAE Local Terrorist List
- INTERPOL Red Notices
- PEP (Politically Exposed Persons) Databases
- FATF High-Risk Jurisdictions
- Additional regional and sectoral lists

### 6.4 UAE Regulatory Calendar (55 Items, 9 Categories)

1. Regulatory Filings
2. Licenses and Renewals
3. Audits and Inspections
4. Risk Assessments
5. Policies and Procedures
6. Training and Awareness
7. Ongoing Monitoring
8. FATF/International Obligations
9. Governance and Oversight

---

## 7. Key Features

### 7.1 AI-Powered Analysis
- Multi-provider fallback chain: Claude -> OpenAI -> Gemini
- Dynamic system prompt builder tailored to UAE DPMS requirements
- JSON repair and fallback parsing for robust LLM response handling
- Compliance gap identification with severity ratings and recommendations

### 7.2 Risk Assessment & Scoring
- Entity-Wide Risk Assessment (EWRA)
- Business-Wide Risk Assessment (BWRA)
- Customer risk scoring during onboarding
- Shipment risk scoring with multi-factor analysis (country risk, amount, material type)
- Color-coded risk visualization (Green/Amber/Red)

### 7.3 Professional Export Capabilities
- **PDF Export**: Color-coded with dark header bands, gold accents, risk-level pills, scoring legends, regulatory footers (via jsPDF)
- **Word Export**: Full HTML/CSS styling with Calibri font, colored badges, info grids, BOM marker for encoding
- **CSV Export**: Standard data export for all major data types
- **goAML XML**: UAE FIU-compliant XML for STR, SAR, CTR, FFR, and HRC reports

### 7.4 Security
- AES-GCM 256-bit encryption for vault documents
- PBKDF2 key derivation with configurable iterations
- Role-based access control (Admin, Compliance Officer, Analyst, Viewer)
- Cloudflare Worker proxy for API key protection
- No server-side data storage - all data remains in the user's browser

### 7.5 Multi-Tenancy
- 6 company profiles with fully isolated data
- Company-scoped storage keys via `scopeKey()` function
- Quick company switching with automatic data loading
- Per-company settings and configurations

### 7.6 Asana Integration
- Automatic task creation for compliance events
- 3-minute auto-sync cycle
- Retry queue with max 40 items for failed operations
- Conflict detection via sync fingerprinting
- Module health tracking (Healthy/Degraded/Error status)
- Synchronized modules: Risk Assessments, EWRA, BWRA, Compliance Manual, Incidents, Onboarding, Deadlines, Screening, Management Approvals, Workflow Tasks

### 7.7 Monitoring & Alerts
- AED 55,000 cash transaction threshold monitoring
- Structuring pattern detection
- Sanctions screening with match logging
- Email alerts via EmailJS
- Slack webhook notifications
- Browser native notifications
- Hourly reminder system
- Regulatory deadline countdown

### 7.8 Training Management
- 77 training topics covering all AML/CFT competency areas
- Employee training record tracking
- Training attachment management
- Export to PDF, Word, and CSV

### 7.9 Workflow Automation
- Custom automation rules with triggers and actions
- 5 built-in compliance checklists:
  1. New Customer Onboarding
  2. Periodic Review
  3. STR Filing
  4. Incident Response
  5. MOE Inspection Readiness
- Document version control with audit trail
- Asana task creation from workflow triggers

---

## 8. Data Persistence

### 8.1 Storage Architecture

All data is stored client-side using the `fgl_` prefix convention:

| Category | Key Examples | Description |
|----------|-------------|-------------|
| **Configuration** | `fgl_keys`, `fgl_active_company`, `fgl_company_profiles` | API keys, tenant selection, company details |
| **Shipments** | `fgl_shipments`, `fgl_local_shipments` | Shipment records (40+ fields per record) |
| **Compliance** | `fgl_evidence`, `fgl_gaps_v2`, `fgl_incidents`, `fgl_screening` | Core compliance data |
| **Assessments** | `fgl_risk_assessments`, `fgl_ewra`, `fgl_bwra`, `fgl_mgmt_approvals` | Risk assessment records |
| **People** | `fgl_employee_training`, `fgl_employee_info`, `fgl_onboarding` | Employee and customer records |
| **Reports** | `fgl_iar_reports`, `fgl_goaml_reports`, `fgl_compliance_manual` | Generated reports |
| **Sync** | `fgl_asana_sync`, `fgl_integration_status` | Integration state and retry queues |
| **Security** | `fgl_vault`, `fgl_vault_encrypted`, `fgl_users`, `fgl_session` | Encrypted storage and auth |
| **Monitoring** | `fgl_threshold_alerts`, `fgl_ctr_queue`, `fgl_sanctions_refresh` | Alert and monitoring data |
| **Analytics** | `fgl_analytics_history`, `fgl_analytics_snapshots` | Dashboard metrics (365-day retention) |

### 8.2 Storage Limits

| Data Type | Maximum Entries |
|-----------|----------------|
| Audit Trail | 500 entries |
| Screening History | 200 entries |
| Analytics Snapshots | 365 days |
| Asana Retry Queue | 40 items |
| Integration Log | 500 entries |

---

## 9. External Libraries

| Library | Version | CDN | Purpose |
|---------|---------|-----|---------|
| **jsPDF** | 2.5.1 | cdnjs | PDF generation for all export functions |
| **EmailJS** | 4.x | jsDelivr | Browser-based email notifications |
| **Chart.js** | 4.4.7 | jsDelivr | Analytics dashboard charts and visualizations |

### Fonts (Google Fonts)
- **DM Mono** (400, 500) - Monospace font for data displays
- **Inter** (300-800) - Primary sans-serif UI font
- **DM Sans** (300-500) - Secondary sans-serif font

---

## 10. Deployment & Configuration

### 10.1 GitHub Pages
- Automatic deployment via `.github/workflows/pages.yml`
- Triggers on push to `main` branch
- Static file serving with `.nojekyll` bypass

### 10.2 Cloudflare Worker Proxy
- Routes all external API calls securely
- Stores API keys server-side (not exposed to browser)
- Supports: Anthropic, OpenAI, Gemini, Asana, Notion, ClickUp, metals pricing APIs

### 10.3 Required Setup
1. Deploy Cloudflare Worker with API keys
2. Enter Proxy URL in Settings tab
3. Configure Asana token and project ID
4. (Optional) Configure additional integrations

---

## 11. Architecture Summary

```
Browser (Client-Side SPA)
|
|-- index.html (11,256 lines - Core UI + Logic)
|-- /modules/ (15 JS files - Feature Modules)
|
|-- localStorage / IndexedDB (Data Persistence)
|-- AES-GCM Vault (Encrypted Storage)
|
|-- Cloudflare Worker Proxy
|   |-- Anthropic Claude API
|   |-- OpenAI API
|   |-- Google Gemini API
|   |-- Asana API
|   |-- Notion API
|   |-- ClickUp API
|   |-- Metals Pricing APIs
|
|-- Direct Connections
|   |-- EmailJS (Email Alerts)
|   |-- Slack Webhooks
|   |-- Google Drive (OAuth 2.0)
|   |-- Google Fonts CDN
|   |-- jsPDF / Chart.js CDN
```

---

**End of Report**
