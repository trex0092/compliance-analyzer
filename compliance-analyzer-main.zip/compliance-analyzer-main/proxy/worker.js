/**
 * Fine Gold Analyser — Cloudflare Worker API Proxy v2.3
 *
 * Routes:
 *   POST /anthropic            → https://api.anthropic.com/v1/messages
 *   POST /openai               → https://api.openai.com/v1/chat/completions
 *   POST /gemini               → https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent
 *   GET|POST|PUT /asana/*      → https://app.asana.com/api/1.0/*
 *   GET|POST /notion/*         → https://api.notion.com/v1/*
 *   POST /slack                → Slack Incoming Webhook
 *   GET|POST /clickup/*        → https://api.clickup.com/api/v2/*
 *   POST /webhooks/asana       → Asana webhook receiver (handshake + events)
 *   POST /webhooks/slack       → Slack webhook receiver (verification + events)
 *   GET  /webhooks/events      → Poll queued webhook events
 *
 * Required Worker secrets (set via `wrangler secret put` or Cloudflare dashboard):
 *   ANTHROPIC_KEY   — Anthropic API key (sk-ant-...)
 *   ASANA_TOKEN     — Asana personal access token (1/xxxxxxxx...)
 *
 * Optional Worker secrets:
 *   OPENAI_KEY      — OpenAI API key (sk-...)
 *   GEMINI_KEY      — Google Gemini API key (AIza...)
 *   NOTION_TOKEN    — Notion integration token (ntn_...)
 *   CLICKUP_TOKEN   — ClickUp API token (pk_...)
 */

// ── In-memory webhook event queue (max 1000, FIFO) ──────────────────────────
const webhookEventQueue = [];
const MAX_WEBHOOK_EVENTS = 1000;

function generateEventId() {
  return 'evt_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 10);
}

function enqueueEvent(source, type, data) {
  const event = {
    id: generateEventId(),
    source,
    type,
    data,
    timestamp: new Date().toISOString(),
    read: false,
  };
  webhookEventQueue.push(event);
  while (webhookEventQueue.length > MAX_WEBHOOK_EVENTS) {
    webhookEventQueue.shift();
  }
  return event;
}

const ALLOWED_ORIGINS = [
  'https://trex051192.github.io',
  'https://compliancetool.com',
  'https://www.compliancetool.com',
];

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    const matchedOrigin = ALLOWED_ORIGINS.includes(origin) ? origin : '';

    const corsHeaders = {
      'Access-Control-Allow-Origin': matchedOrigin || ALLOWED_ORIGINS[0],
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
      'Access-Control-Max-Age': '86400',
    };

    // ── CORS preflight ────────────────────────────────────────────────────────
    if (request.method === 'OPTIONS') {
      return new Response(null, { status: 204, headers: corsHeaders });
    }

    // ── Origin guard ─────────────────────────────────────────────────────────
    if (!matchedOrigin) {
      return new Response(JSON.stringify({ error: 'Forbidden' }), {
        status: 403,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    const url = new URL(request.url);
    const path = url.pathname;
    const jsonHeaders = { ...corsHeaders, 'Content-Type': 'application/json' };

    // ── Anthropic proxy ───────────────────────────────────────────────────────
    if (path === '/anthropic') {
      if (request.method !== 'POST') {
        return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: jsonHeaders });
      }
      const body = await request.text();
      const upstream = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': env.ANTHROPIC_KEY,
          'anthropic-version': '2023-06-01',
        },
        body,
      });
      return new Response(await upstream.text(), { status: upstream.status, headers: jsonHeaders });
    }

    // ── OpenAI proxy ──────────────────────────────────────────────────────────
    if (path === '/openai') {
      if (request.method !== 'POST') {
        return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: jsonHeaders });
      }
      const body = await request.text();
      const upstream = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${env.OPENAI_KEY}`,
        },
        body,
      });
      return new Response(await upstream.text(), { status: upstream.status, headers: jsonHeaders });
    }

    // ── Gemini proxy ──────────────────────────────────────────────────────────
    if (path === '/gemini') {
      if (request.method !== 'POST') {
        return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: jsonHeaders });
      }
      const body = await request.text();
      const upstream = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${env.GEMINI_KEY}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body,
      });
      return new Response(await upstream.text(), { status: upstream.status, headers: jsonHeaders });
    }

    // ── Asana proxy ───────────────────────────────────────────────────────────
    if (path.startsWith('/asana/')) {
      const asanaSubPath = path.slice('/asana'.length);
      const asanaUrl = new URL('https://app.asana.com/api/1.0' + asanaSubPath);
      url.searchParams.forEach((v, k) => asanaUrl.searchParams.set(k, v));

      const reqHeaders = { 'Authorization': `Bearer ${env.ASANA_TOKEN}`, 'Accept': 'application/json' };
      const fetchOpts = { method: request.method, headers: reqHeaders };
      if (request.method !== 'GET' && request.method !== 'HEAD') {
        reqHeaders['Content-Type'] = 'application/json';
        fetchOpts.body = await request.text();
      }

      const upstream = await fetch(asanaUrl.toString(), fetchOpts);
      return new Response(await upstream.text(), { status: upstream.status, headers: jsonHeaders });
    }

    // ── Notion proxy ──────────────────────────────────────────────────────────
    if (path.startsWith('/notion/')) {
      const notionSubPath = path.slice('/notion'.length);
      const notionUrl = new URL('https://api.notion.com/v1' + notionSubPath);
      url.searchParams.forEach((v, k) => notionUrl.searchParams.set(k, v));

      const reqHeaders = {
        'Authorization': `Bearer ${env.NOTION_TOKEN}`,
        'Notion-Version': '2022-06-28',
        'Accept': 'application/json',
      };
      const fetchOpts = { method: request.method, headers: reqHeaders };
      if (request.method !== 'GET' && request.method !== 'HEAD') {
        reqHeaders['Content-Type'] = 'application/json';
        fetchOpts.body = await request.text();
      }

      const upstream = await fetch(notionUrl.toString(), fetchOpts);
      return new Response(await upstream.text(), { status: upstream.status, headers: jsonHeaders });
    }

    // ── Slack proxy ───────────────────────────────────────────────────────────
    if (path === '/slack') {
      if (request.method !== 'POST') {
        return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: jsonHeaders });
      }
      const payload = await request.json();
      const webhookUrl = payload.webhookUrl;
      if (!webhookUrl || !webhookUrl.startsWith('https://hooks.slack.com/')) {
        return new Response(JSON.stringify({ error: 'Invalid Slack webhook URL' }), { status: 400, headers: jsonHeaders });
      }
      const { webhookUrl: _, ...slackPayload } = payload;
      const upstream = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(slackPayload),
      });
      return new Response(await upstream.text(), { status: upstream.status, headers: jsonHeaders });
    }

    // ── ClickUp proxy ─────────────────────────────────────────────────────────
    if (path.startsWith('/clickup/')) {
      const clickupSubPath = path.slice('/clickup'.length);
      const clickupUrl = new URL('https://api.clickup.com/api/v2' + clickupSubPath);
      url.searchParams.forEach((v, k) => clickupUrl.searchParams.set(k, v));

      const reqHeaders = { 'Authorization': env.CLICKUP_TOKEN, 'Accept': 'application/json' };
      const fetchOpts = { method: request.method, headers: reqHeaders };
      if (request.method !== 'GET' && request.method !== 'HEAD') {
        reqHeaders['Content-Type'] = 'application/json';
        fetchOpts.body = await request.text();
      }

      const upstream = await fetch(clickupUrl.toString(), fetchOpts);
      return new Response(await upstream.text(), { status: upstream.status, headers: jsonHeaders });
    }

    // ── Asana webhook receiver ──────────────────────────────────────────────
    if (path === '/webhooks/asana') {
      // Asana handshake: respond with X-Hook-Secret to confirm subscription
      const hookSecret = request.headers.get('X-Hook-Secret');
      if (hookSecret) {
        return new Response('', {
          status: 200,
          headers: { ...corsHeaders, 'X-Hook-Secret': hookSecret },
        });
      }

      if (request.method !== 'POST') {
        return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: jsonHeaders });
      }

      try {
        const payload = await request.json();
        const events = payload.events || [];
        for (const evt of events) {
          const type = evt.action || evt.type || 'unknown';
          enqueueEvent('asana', type, {
            gid: evt.resource && evt.resource.gid,
            resourceType: evt.resource && evt.resource.resource_type,
            name: evt.resource && evt.resource.name,
            parent: evt.parent && evt.parent.gid,
            user: evt.user && evt.user.gid,
          });
        }
        return new Response(JSON.stringify({ ok: true, received: events.length }), { status: 200, headers: jsonHeaders });
      } catch (e) {
        return new Response(JSON.stringify({ error: 'Invalid payload' }), { status: 400, headers: jsonHeaders });
      }
    }

    // ── Slack webhook receiver ────────────────────────────────────────────────
    if (path === '/webhooks/slack') {
      if (request.method !== 'POST') {
        return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: jsonHeaders });
      }

      try {
        const payload = await request.json();

        // Slack URL verification challenge
        if (payload.type === 'url_verification' && payload.challenge) {
          return new Response(JSON.stringify({ challenge: payload.challenge }), { status: 200, headers: jsonHeaders });
        }

        // Process event callbacks
        if (payload.event) {
          const evt = payload.event;
          enqueueEvent('slack', evt.type || 'message', {
            text: evt.text,
            user: evt.user,
            channel: evt.channel,
            ts: evt.ts,
            reaction: evt.reaction,
            item: evt.item,
          });
        }

        return new Response(JSON.stringify({ ok: true }), { status: 200, headers: jsonHeaders });
      } catch (e) {
        return new Response(JSON.stringify({ error: 'Invalid payload' }), { status: 400, headers: jsonHeaders });
      }
    }

    // ── Poll webhook events ───────────────────────────────────────────────────
    if (path === '/webhooks/events') {
      if (request.method !== 'GET') {
        return new Response(JSON.stringify({ error: 'Method not allowed' }), { status: 405, headers: jsonHeaders });
      }

      // Return and drain queued events
      const events = webhookEventQueue.splice(0, webhookEventQueue.length);
      return new Response(JSON.stringify({ events, count: events.length }), { status: 200, headers: jsonHeaders });
    }

    return new Response(JSON.stringify({ error: 'Not found' }), { status: 404, headers: jsonHeaders });
  },
};
